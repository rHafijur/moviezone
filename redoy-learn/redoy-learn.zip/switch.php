<?php
    $a=20;
    switch($a){
        case 10:
        echo "The number is Ten";
        break;
        case 20:
        echo "The number is Twenty";
        break;
        default:
        echo "Other number";
        break;
    }
?>