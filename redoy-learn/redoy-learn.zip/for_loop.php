<?php
    // $sum=0;
    // for($i=1;$i<=100;$i++){
    //     $sum=$sum+$i;
    // }
    // echo "The sum of 1......100 is ".$sum;
    
    
    // for($i=1;$i<=100;$i=$i+2){
    //     echo $i."<br>";
    // }

    // for($i=1;$i<=100;$i++){
    //     if($i%2==1){
    //         continue;
    //     }
    //     echo $i."<br>";
    // }
    for($i=1;$i<=100;$i++){
        if($i%2==1){
            continue;
        }
        echo $i."<br>";
    }
    
?>