<?php
    $a=0;
    $b=10;
    if($a+$b<30){
        echo "The number is smaller than 30";
    }elseif($a+$b==30){
        echo "The number is equal to 30";
    }else{
        echo "The number is bigger than 30";
    }

?>