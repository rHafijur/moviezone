<?php
    $friends=[
        'best_friend'=> 'Rahim',
        'worst_friend'=> 'Karim',
        'Alamin',
        'Robin',
        'Mike',
        'Shinoda'
    ];
    // foreach($friends as $man){
    //     echo $man." <br>";
    //     // if($man=="Robin"){
    //     //     break;
    //     // }

    // }
    echo $friends['worst_friend'];
?>