<?php
    // $i=1;
    // while($i<=100){
    //     echo $i++. "<br>";
    // }
    $i=1;
    while(true){
        echo $i. "<br>";
        if($i++==50){
            break;
        }
    }
?>