<?php
$a=101;
$b=50;
$sum=$a+$b;
// echo $sum;
$sub=$a-$b;
// echo $sub;
$mul=$a*$b;
// echo $mul;
$div=$a/$b;
// echo $div;
$mod=$a%$b;
echo $mod;
?>